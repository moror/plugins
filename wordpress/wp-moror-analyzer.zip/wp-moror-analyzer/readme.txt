=== WP Moror Analyzer ===
Contributors: Moror
Tags: moror, analyze, heatmap, geolocation, visitor
Requires at least: 3.0
Tested up to: 3.9.1

This plugin add Moror analyzer code to your site.

== Description ==

This plugin add Moror analyzer code to your site.

== Installation ==

1. Upload the full directory into your wp-content/plugins directory
2. Activate the plugin at the plugin administration page
3. Open the plugin configuration page, which is located under "Settings -> WP Moror Analyzer" and customize settings.

== Screenshots ==

1. The settings menu

== Changelog ==

= 0.0.1 =
* first version.
